"""
Configuração central do ASTRA SPECTRE (versão Orange Pi).

IMPORTANTE - PINOS:
Os valores abaixo são números wPi (wiringOP), não os pinos físicos do
header nem os nomes usados no código do ESP32. Para descobrir o wPi de
cada pino físico, rode:

    sudo gpio readall

e procure a coluna "wPi" ao lado do "Physical" onde você ligou o fio.

Já confirmamos: LED de teste no físico 12 = wPi 6. Preenchi LED_VERDE
com esse valor como ponto de partida - troque se ligar esse LED em
outro pino físico.

Os demais (TROCAR) são placeholders. Ligue cada componente, rode
`sudo gpio readall` de novo, e substitua pelo wPi correto.
"""

# ================= PINOS (wPi) =================
PINOS = {
    # LEDs
    "LED_VERDE":   6,        # físico 12 - já testado e funcionando
    "LED_AMARELO": "TROCAR", # ex: 5
    "LED_AZUL":    "TROCAR",

    # Botões (INPUT_PULLUP - pressionado = nível baixo)
    "BTN_VERDE":   "TROCAR",
    "BTN_AMARELO": "TROCAR",
    "BTN_AZUL":    "TROCAR",
    "BTN_PRETO":   "TROCAR",

    # Buzzer ativo (liga/desliga simples)
    "BUZZER": "TROCAR",
}

# ================= I2C (OLED) =================
# Endereço padrão do SSD1306. Se `i2cdetect` mostrar outro endereço
# (ex: 0x3D), troque aqui.
OLED_I2C_ADDRESS = 0x3C
OLED_WIDTH = 128
OLED_HEIGHT = 64
# Deixe None para autodetectar o barramento I2C (recomendado).
# Se quiser forçar um barramento específico (ex: /dev/i2c-3), coloque 3.
OLED_I2C_BUS = None

# ================= MQTT =================
MQTT_BROKER = "192.168.0.15"
MQTT_PORT = 1883
MQTT_CLIENT_ID = "OrangePi_ASTRA"

TOPICO_STATUS       = "astra/status"
TOPICO_MANHA        = "astra/manha"
TOPICO_NOITE        = "astra/noite"
TOPICO_ALARME       = "astra/alarme"
TOPICO_CMD          = "astra/cmd"
TOPICO_HORARIO_MANHA = "astra/horario/manha"
TOPICO_HORARIO_NOITE = "astra/horario/noite"

# ================= ALARMES (padrão) =================
HORA_MANHA_PADRAO = 9
MIN_MANHA_PADRAO  = 0
HORA_NOITE_PADRAO = 22
MIN_NOITE_PADRAO  = 0

# ================= ARQUIVO DE ESTADO =================
# Substitui o Preferences/NVS do ESP32.
ARQUIVO_ESTADO = "/home/orangepi/Projetos/astra_estado.json"

# ================= TIMEZONE =================
# A Orange Pi deve estar com o fuso horário correto do sistema.
# Rode uma vez: sudo timedatectl set-timezone America/Sao_Paulo
