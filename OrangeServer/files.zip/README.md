# ASTRA SPECTRE - Orange Pi

Porte do firmware ESP32 (Arduino) para Python rodando na Orange Pi.

## 1. Copiar o projeto
Copie esta pasta inteira para `/home/orangepi/Projetos/orangepi_astra` (ou onde preferir).

## 2. Instalar dependências
```bash
pip install -r requirements.txt --break-system-packages
```

Garanta também que o **wiringOP** está instalado (você já usou `gpio` no teste do LED, então já está ok).

## 3. Habilitar o I2C (para o OLED)
Se ainda não estiver habilitado, use o utilitário de configuração da sua imagem
(`orangepi-config` ou `armbian-config` → System → Hardware → habilite o overlay de i2c
correspondente ao pino que você está usando) e reinicie.

Depois, confirme que o OLED responde:
```bash
sudo i2cdetect -l          # lista os barramentos disponíveis
sudo i2cdetect -y <numero> # deve mostrar "3c" na grade
```

## 4. Configurar o fuso horário
```bash
sudo timedatectl set-timezone America/Sao_Paulo
```

## 5. Preencher os pinos em `config.py`
1. Ligue cada componente (LEDs, botões, buzzer) num pino físico livre do header.
2. Rode `sudo gpio readall` e anote o `wPi` correspondente a cada `Physical`.
3. Edite `config.py` e troque cada `"TROCAR"` pelo número wPi certo.

O `LED_VERDE` já está preenchido com `6` (físico 12), que você validou anteriormente.
Se for usar esse mesmo pino pra outro LED, ajuste conforme sua fiação real.

## 6. Rodar
GPIO exige root:
```bash
sudo python3 main.py
```

## 7. Deixar rodando sempre (systemd) - opcional
Crie `/etc/systemd/system/astra.service`:
```ini
[Unit]
Description=ASTRA SPECTRE
After=network-online.target

[Service]
ExecStart=/usr/bin/python3 /home/orangepi/Projetos/orangepi_astra/main.py
WorkingDirectory=/home/orangepi/Projetos/orangepi_astra
Restart=always
User=root

[Install]
WantedBy=multi-user.target
```
Depois:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now astra
sudo journalctl -u astra -f   # ver os logs
```

## O que mudou em relação ao ESP32
- **WiFi**: removido do código - a Orange Pi já fica na rede via NetworkManager/nmcli.
  Configure o Wi-Fi normalmente pelo `nmtui` ou `nmcli`, fora do projeto.
- **NTP**: o Linux sincroniza a hora sozinho (systemd-timesyncd). Só é preciso configurar
  o fuso horário certo (`timedatectl`).
- **Preferences (NVS)** → arquivo `astra_estado.json` (caminho configurável em `config.py`).
- **Buzzer**: como é ativo, simplificamos para liga/desliga (sem PWM de tom).
- **GPIO**: usa o comando `gpio` do wiringOP via `subprocess`, igual ao seu teste do LED.
